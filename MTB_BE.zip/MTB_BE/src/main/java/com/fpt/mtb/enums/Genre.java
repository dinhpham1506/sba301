package com.fpt.mtb.enums;

import com.fasterxml.jackson.annotation.JsonCreator;
import com.fasterxml.jackson.annotation.JsonValue;

import java.util.Arrays;

public enum Genre {
    ACTION("Action"),
    COMEDY("Comedy"),
    DRAMA("Drama"),
    HORROR("Horror"),
    SCI_FI("Sci-Fi"),
    ROMANCE("Romance");

    private final String label;

    Genre(String label) {
        this.label = label;
    }

    @JsonValue
    public String getLabel() {
        return label;
    }

    /** Accepts "Sci-Fi" (label) or "SCI_FI" (name), case-insensitive. Unknown value -> exception -> 400 Malformed. */
    @JsonCreator
    public static Genre from(String value) {
        if (value == null) return null;
        String v = value.trim();
        return Arrays.stream(values())
                .filter(g -> g.label.equalsIgnoreCase(v) || g.name().equalsIgnoreCase(v))
                .findFirst()
                .orElseThrow(() -> new IllegalArgumentException("Invalid genre: " + value));
    }
}
