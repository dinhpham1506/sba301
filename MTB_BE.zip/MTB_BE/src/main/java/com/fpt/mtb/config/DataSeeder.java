package com.fpt.mtb.config;

import com.fpt.mtb.entity.Movie;
import com.fpt.mtb.enums.AgeRating;
import com.fpt.mtb.enums.Genre;
import com.fpt.mtb.enums.MovieStatus;
import com.fpt.mtb.repository.MovieRepository;
import lombok.RequiredArgsConstructor;
import org.springframework.boot.CommandLineRunner;
import org.springframework.stereotype.Component;

import java.time.LocalDate;
import java.util.List;

/** Inserts 15 sample movies the first time (only when the table is empty). */
@Component
@RequiredArgsConstructor
public class DataSeeder implements CommandLineRunner {

    private final MovieRepository movieRepository;

    @Override
    public void run(String... args) {
        if (movieRepository.count() > 0) return;

        movieRepository.saveAll(List.of(
                m("Beyond the Stars", Genre.SCI_FI, "Tran Minh", 150, 110000, "2027-01-10", AgeRating.C13, "English", MovieStatus.UPCOMING),
                m("City of Dreams", Genre.DRAMA, "Le Thu Ha", 132, 95000, "2026-12-05", AgeRating.C16, "Vietnamese", MovieStatus.UPCOMING),
                m("Dragon Storm", Genre.ACTION, "Pham Quang", 128, 95000, "2026-11-25", AgeRating.C13, "English", MovieStatus.UPCOMING),
                m("Funny Business", Genre.COMEDY, "Nguyen Hoa", 88, 72000, "2026-09-20", AgeRating.P, "Vietnamese", MovieStatus.ENDED),
                m("Galaxy Warriors", Genre.SCI_FI, "Linh Dang", 125, 90000, "2026-11-10", AgeRating.C13, "English", MovieStatus.SHOWING),
                m("Haunted Manor", Genre.HORROR, "Vo Thanh", 105, 85000, "2026-10-31", AgeRating.C18, "English", MovieStatus.SHOWING),
                m("Love in Hanoi", Genre.ROMANCE, "Do My Linh", 112, 80000, "2026-02-14", AgeRating.C13, "Vietnamese", MovieStatus.ENDED),
                m("Midnight Run", Genre.ACTION, "Bui Duc", 118, 90000, "2026-11-15", AgeRating.C16, "English", MovieStatus.SHOWING),
                m("Ocean Whisper", Genre.DRAMA, "Hoang Lan", 140, 100000, "2026-12-20", AgeRating.P, "Japanese", MovieStatus.UPCOMING),
                m("Pixel Panic", Genre.COMEDY, "Ngo Tuan", 95, 75000, "2026-08-01", AgeRating.P, "English", MovieStatus.ENDED),
                m("Red Moon", Genre.HORROR, "Dang Khoa", 99, 85000, "2027-02-02", AgeRating.C18, "Korean", MovieStatus.UPCOMING),
                m("Silent Echo", Genre.SCI_FI, "Mai Anh", 135, 105000, "2026-11-20", AgeRating.C13, "English", MovieStatus.SHOWING),
                m("Summer Letters", Genre.ROMANCE, "Truong Vy", 108, 78000, "2026-07-07", AgeRating.P, "Vietnamese", MovieStatus.ENDED),
                m("The Last Guardian", Genre.ACTION, "Ly Hung", 145, 120000, "2026-12-24", AgeRating.C16, "English", MovieStatus.UPCOMING),
                m("Winter Tale", Genre.DRAMA, "Phan Ngoc", 126, 88000, "2026-11-01", AgeRating.C13, "French", MovieStatus.SHOWING)
        ));
    }

    private Movie m(String title, Genre genre, String director, int duration, int price,
                    String releaseDate, AgeRating ageRating, String language, MovieStatus status) {
        return Movie.builder()
                .title(title).genre(genre).director(director)
                .duration(duration).ticketPrice(price)
                .releaseDate(LocalDate.parse(releaseDate))
                .ageRating(ageRating).language(language).status(status)
                .build();
    }
}
