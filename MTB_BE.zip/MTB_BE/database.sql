-- Run once in SSMS before starting the API.
-- Table Movies is created automatically by Hibernate (ddl-auto=update)
-- and 15 sample movies are seeded on first start (DataSeeder).
IF DB_ID('SBA301_2026_PE') IS NULL
    CREATE DATABASE SBA301_2026_PE;
GO
